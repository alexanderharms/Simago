# Simago: Population simulation

This package can be used to generate random populations, sets of microdata, based
on (publicly availabled) aggregated data.  

These populations can then for example be used for experimentation in the field
of machine learning or simulation studies.

## Usage
To use the package install the wheel file in the 'dist' folder. 

To generate a population the 'generate_population' from 'simago.population' has
to be called. This function creates a population in the form of tablfe with a
row for every person and a column for each property of this person. The values
for these properties are randomly drawn from probability distributions defined
by the supplied data. This is done by supplying a settings file, a data file and
possibly a conditionals file. To see how this works one can look at the example
described in de documentation.

<!--
## Data for the Chicago-based population
Data sources:
* US Census American Community Survey of 2013-2017.
* Chicago Data Portal: Building Footprints & Boundaries ZIP codes, 
	retrieved in July 2019.
* Trulia: median Sales & Listing prices per ZIP code; median rent price/bedroom, 
	retrieved on September 1st 2019.
-->
