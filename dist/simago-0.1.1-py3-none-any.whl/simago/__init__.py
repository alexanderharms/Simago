"""
Simago: Randomly generate populations

"""

